Codebreaker
===========

Codebreaker is an HTML/CSS/Javascript implementation of the code-breaking game [Bulls and Cows][1].  Similar to the [Mastermind board game][2], codebreaker uses a pattern of colors.

I originally wrote Codbreaker in 2011 as an excercise in CSS and Javascript.  The code is a bit messy, to say the very least, but I hope to clean it up significantly and package it as a node-webkit app.

[1]: http://en.wikipedia.org/wiki/Bulls_and_cows
[2]: http://en.wikipedia.org/wiki/Mastermind_(board_game)